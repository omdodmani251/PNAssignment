from django.contrib import admin
from .models import Dishes

admin.site.register(Dishes)
# Register your models here.
