from django.shortcuts import render
from django.http import HttpResponse
from .models import Dishes

def search(request):
    query=request.POST['query']
    search_dishes=Dishes.objects.filter(name__icontains=query)
    params={'results':search_dishes,'query':query}
    return render(request,'search_result.html',params)

def index(request):
  
    return render(request,'search_page.html')
    # return HttpResponse('Searching...')
# Create your views here.
